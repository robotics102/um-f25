/**
 * File: utils.cpp
 *
 * Utility functions to be used in driver programs. 
 */

#include <pocket_calculator/common/utils.h>


float addTwoNumbers(float operand1, float operand2) {
    // *** Task: Implement this function according to the header file *** //

    return 0;

    // *** End student code *** //
}

float subtractTwoNumbers(float operand1, float operand2) {
    // *** Task: Implement this function according to the header file *** //

    return 0;

    // *** End student code *** //
}

void multiplyTwoNumbers(float operand1, float operand2, float &product) {
    // *** Task: Implement this function according to the header file *** //

    // *** End student code *** //
}

bool divideTwoNumbers(float operand1, float operand2, float &quotient) {
    // *** Task: Implement this function according to the header file *** //

    return false;

    // *** End student code *** //
}

void getNumber(std::ostream& output_stream, std::istream& input_stream, float &number) {
    // *** Task: Implement this function according to the header file *** //

    // *** End student code *** //
}

bool getOperator(std::ostream& output_stream, std::istream& input_stream, char &operation) {
    // *** Task: Implement this function according to the header file *** //

    return false;

    // *** End student code *** //
}

bool performOperation(float operand1, char operation, float operand2,
                      float &result) {
    // *** Task: Implement this function according to the header file *** //

    return false;

    // *** End student code *** //
}
