#include <iostream>
#include <vector>
#include <cmath>

#include <path_planning/utils/math_helpers.h>
#include <path_planning/utils/graph_utils.h>

#include <path_planning/graph_search/distance_transform.h>


void distanceTransformSlow(GridGraph& graph)
{
    // *** Task: Implement this function if completing the advanced extensions *** //

    // *** End student code *** //
}

void distanceTransformManhattan(GridGraph& graph)
{
    // *** Task: Implement this function if completing the advanced extensions *** //

    // *** End student code *** //
}

std::vector<float> distanceTransformEuclidean1D(std::vector<float>& init_dt)
{
    // *** Task: Implement this function if completing the advanced extensions *** //

    std::vector<float> distances_out;
    return distances_out;

    // *** End student code *** //
}

void distanceTransformEuclidean2D(GridGraph& graph)
{
    // *** Task: Implement this function if completing the advanced extensions *** //

    // *** End student code *** //
}
